# 사용자로부터 두 개의 정수를 입력받아서 두 수의 합을 구하는 프로그램을 만드는 방법

x = int(input("첫 번째 정수 : "))
y = int(input("두 번째 정수 : "))

sum = x + y
diff = x - y
print("두 수의 합 : ", sum)
print("두 수의 차이 : ", diff)
